# CCTiers

Tier tagger for Fabric 1.21.11 - author: AyushXDP

- Gamemode icon + tier (HT3, LT2 ...) before player names on nametags and in the tab list
- `/cctiers <player>` - player search result screen (all gamemodes, peak tier, region, overall)
- `/cctiers config` - settings screen (mod on/off, nametags, tab, icons, own tag, which gamemode to show, API URL)
- Chat tags, `/cctiers toggle`, `/cctiers refresh`, `/cctiers register`
- Settings file: `config/cctiers.json`

## API
Default base URL: `https://api.hypen9.qzz.io` (change in `/cctiers config` or `config/cctiers.json`).

- `GET  /players/{name}` - one player (if it answers 404 the mod tries the list below)
- `GET  /players` - list of players (array, or `{"players":[...]}`), the right one is picked by name
- `POST /players` - first use: registers the local player `{"name","uuid","source":"cctiers-mod"}` (200/201/409 = ok). Turn off with "Register me" in the config, or `/cctiers register` to retry.

A player looks like:
```json
{ "name": "Steve", "region": "AS", "points": 120, "overall": 5,
  "rankings": { "crystal": { "tier": 2, "pos": 0, "peak_tier": 1, "peak_pos": 1, "retired": false } } }
```
or `{ "name": "Steve", "tiers": { "sword": "HT3", "crystal": "LT2" } }`.
Gamemodes: crystal, sword, axe, pot, neth_pot, smp, mace, uhc, vanilla. `pos` 0 = HT, 1 = LT.

## Mod Menu
Config button via Mod Menu (optional). If the build can't find Mod Menu, change `modmenu_version` in gradle.properties to `17.0.1-beta.1`.

## Build
Push this folder to a GitHub repo - the workflow in `.github/workflows/build.yml` builds it.
Download the `cctiers` artifact from the Actions tab (jar inside). Needs Fabric API on 1.21.11.
