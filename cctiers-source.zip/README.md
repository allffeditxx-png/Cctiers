# CCTiers

Tier tagger for Fabric 1.21.11 - author: AyushXDP

- Nametags, tab list and chat: `[icon] HT4 | Name | LT3 [icon]` (best tier before the name, second best after it)
- `/cctiers <player>` - player search result screen (region, overall rank, points, every gamemode)
- `/cctiers config` or the Mod Menu button - settings (mod on/off, nametags, tab, chat, icons, second tier, own tag, which gamemode to show, register me, reload)
- `/cctiers toggle`, `/cctiers refresh`, `/cctiers register`
- Settings file: `config/cctiers.json`

## API
Fixed: `https://api.hypen9.qzz.io/players`

- `GET /players` - downloaded once, kept in memory, refreshed every 5 minutes. Format:
  `{ "ayushxdp": { "username": "AyushXDP", "region": "AS", "tiers": { "vanilla": "HT4", "sword": "LT3" } }, ... }`
- `POST /players` - first use: registers the local player `{"username","name","uuid","source":"cctiers-mod"}` (200/201/409 = ok, max 3 tries). Turn off with "Register me" in the config.

Gamemodes: vanilla, crystal, uhc, pot, nethop (Neth Pot), smp, sword, axe, mace, cart, spearmace, diasmp.
Overall rank = points (HT1 60, LT1 45, HT2 30, LT2 20, HT3 10, LT3 6, HT4 4, LT4 3, HT5 2, LT5 1) added up over all gamemodes.

## Mod Menu
Optional. If the build can't find Mod Menu, change `modmenu_version` in gradle.properties to `17.0.1-beta.1`.

## Build
Push this folder to GitHub - the workflow in `.github/workflows/build.yml` builds it.
Download the `cctiers` artifact from the Actions tab (jar inside). Needs Fabric API on 1.21.11.
