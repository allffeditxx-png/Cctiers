package com.cctiers.ui;

import com.cctiers.config.CCConfig;
import com.cctiers.data.GameMode;
import com.cctiers.data.TierApi;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** /cctiers config, and the Mod Menu config button. */
public class ConfigScreen extends Screen {
    private final Screen parent;

    public ConfigScreen(Screen parent) {
        super(Text.literal("CCTiers Config"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        CCConfig c = CCConfig.get();
        int cx = this.width / 2;
        int lx = cx - 155;
        int rx = cx + 5;
        int w = 150;
        int y = Math.max(34, this.height / 2 - 82);
        int step = 24;

        toggle(lx, y, w, "Mod", () -> c.enabled, v -> c.enabled = v);
        toggle(rx, y, w, "Own tag", () -> c.showOwnTag, v -> c.showOwnTag = v);
        y += step;
        toggle(lx, y, w, "Nametags", () -> c.showNametag, v -> c.showNametag = v);
        toggle(rx, y, w, "Tab list", () -> c.showTab, v -> c.showTab = v);
        y += step;
        toggle(lx, y, w, "Chat", () -> c.showChat, v -> c.showChat = v);
        toggle(rx, y, w, "Icons", () -> c.showIcons, v -> c.showIcons = v);
        y += step;
        toggle(lx, y, w, "Second tier", () -> c.showSecondTier, v -> c.showSecondTier = v);

        List<String> options = new ArrayList<>();
        options.add("highest");
        for (GameMode m : GameMode.values()) options.add(m.id);
        this.addDrawableChild(ButtonWidget.builder(displayLabel(c), b -> {
            int i = options.indexOf(c.displayMode);
            c.displayMode = options.get((i + 1) % options.size());
            b.setMessage(displayLabel(c));
            CCConfig.save();
        }).dimensions(rx, y, w, 20).build());
        y += step;

        toggle(lx, y, w, "Register me", () -> c.registerPlayer, v -> c.registerPlayer = v);
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Reload tiers"), b -> TierApi.refresh())
                .dimensions(rx, y, w, 20).build());
        y += step + 6;

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> this.close())
                .dimensions(cx - 100, y, 200, 20).build());
    }

    private void toggle(int x, int y, int w, String label, Supplier<Boolean> get, Consumer<Boolean> set) {
        this.addDrawableChild(ButtonWidget.builder(toggleLabel(label, get.get()), b -> {
            set.accept(!get.get());
            b.setMessage(toggleLabel(label, get.get()));
            CCConfig.save();
        }).dimensions(x, y, w, 20).build());
    }

    private static Text toggleLabel(String label, boolean on) {
        return Text.literal(label + ": " + (on ? "ON" : "OFF"));
    }

    private static Text displayLabel(CCConfig c) {
        GameMode m = GameMode.fromId(c.displayMode);
        return Text.literal("Show: " + (m == null ? "Highest tier" : m.display));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("CCTiers  -  by AyushXDP"), this.width / 2, 14, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        CCConfig.save();
        if (this.client != null) this.client.setScreen(parent);
    }
}
