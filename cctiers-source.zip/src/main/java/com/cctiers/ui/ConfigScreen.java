package com.cctiers.ui;

import com.cctiers.config.CCConfig;
import com.cctiers.data.GameMode;
import com.cctiers.data.TierApi;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** /cctiers config, and the Mod Menu config button. */
public class ConfigScreen extends Screen {
    private final Screen parent;
    private final String startBase;
    private TextFieldWidget urlField;

    public ConfigScreen(Screen parent) {
        super(Text.literal("CCTiers Config"));
        this.parent = parent;
        this.startBase = CCConfig.get().apiBase;
    }

    @Override
    protected void init() {
        CCConfig c = CCConfig.get();
        int cx = this.width / 2;
        int lx = cx - 155;
        int rx = cx + 5;
        int w = 150;
        int y = 32;
        int step = 22;

        toggle(lx, y, w, "Mod", () -> c.enabled, v -> c.enabled = v);
        toggle(rx, y, w, "Own tag", () -> c.showOwnTag, v -> c.showOwnTag = v);
        y += step;
        toggle(lx, y, w, "Nametags", () -> c.showNametag, v -> c.showNametag = v);
        toggle(rx, y, w, "Tab list", () -> c.showTab, v -> c.showTab = v);
        y += step;
        toggle(lx, y, w, "Chat", () -> c.showChat, v -> c.showChat = v);
        toggle(rx, y, w, "Icons", () -> c.showIcons, v -> c.showIcons = v);
        y += step;

        List<String> options = new ArrayList<>();
        options.add("highest");
        for (GameMode m : GameMode.values()) options.add(m.id);
        this.addDrawableChild(ButtonWidget.builder(displayLabel(c), b -> {
            int i = options.indexOf(c.displayMode);
            c.displayMode = options.get((i + 1) % options.size());
            b.setMessage(displayLabel(c));
            CCConfig.save();
        }).dimensions(lx, y, w, 20).build());
        toggle(rx, y, w, "Register me", () -> c.registerPlayer, v -> c.registerPlayer = v);
        y += step;

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Reload all tiers"), b -> TierApi.clear())
                .dimensions(lx, y, w, 20).build());
        y += step + 14;

        urlField = new TextFieldWidget(this.textRenderer, lx, y, 310, 20, Text.literal("API URL"));
        urlField.setMaxLength(300);
        urlField.setText(c.apiBase);
        urlField.setChangedListener(s -> c.apiBase = s);
        this.addDrawableChild(urlField);
        y += step + 4;

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> this.close())
                .dimensions(cx - 100, y, 200, 20).build());
    }

    private void toggle(int x, int y, int w, String label, Supplier<Boolean> get, Consumer<Boolean> set) {
        this.addDrawableChild(ButtonWidget.builder(toggleLabel(label, get.get()), b -> {
            set.accept(!get.get());
            b.setMessage(toggleLabel(label, get.get()));
            CCConfig.save();
        }).dimensions(x, y, w, 20).build());
    }

    private static Text toggleLabel(String label, boolean on) {
        return Text.literal(label + ": " + (on ? "ON" : "OFF"));
    }

    private static Text displayLabel(CCConfig c) {
        GameMode m = GameMode.fromId(c.displayMode);
        return Text.literal("Show: " + (m == null ? "Highest tier" : m.display));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int cx = this.width / 2;
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("CCTiers  -  by AyushXDP"), cx, 14, 0xFFFFFFFF);
        if (urlField != null) {
            ctx.drawTextWithShadow(this.textRenderer, Text.literal("API URL"),
                    urlField.getX(), urlField.getY() - 11, 0xFFAAAAAA);
        }
    }

    @Override
    public void close() {
        CCConfig c = CCConfig.get();
        if (!c.apiBase.equals(startBase)) c.registered = false; // new API -> register again
        CCConfig.save();
        TierApi.clear();
        if (this.client != null) this.client.setScreen(parent);
    }
}
