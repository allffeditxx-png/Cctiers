package com.cctiers.ui;

import com.cctiers.data.GameMode;
import com.cctiers.data.Profile;
import com.cctiers.data.Rank;
import com.cctiers.data.TierApi;
import com.cctiers.util.TierText;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Util;

import java.net.URI;

/** /cctiers <player> - the player search result screen. */
public class ProfileScreen extends Screen {
    private final String name;
    private final TierApi.Entry entry;

    public ProfileScreen(String name) {
        super(Text.literal("CCTiers"));
        this.name = name;
        this.entry = TierApi.forceFetch(name);
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height - 26;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("NameMC"), b -> {
            try {
                Util.getOperatingSystem().open(URI.create("https://namemc.com/profile/" + name));
            } catch (Exception ignored) {
            }
        }).dimensions(cx - 102, y, 100, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> this.close())
                .dimensions(cx + 2, y, 100, 20).build());
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int cx = this.width / 2;

        ctx.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal(name).formatted(Formatting.BOLD), cx, 12, 0xFFFFFFFF);

        TierApi.State st = entry.state;
        if (st == TierApi.State.LOADING) {
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Loading..."), cx, this.height / 2, 0xFFAAAAAA);
            return;
        }
        if (st == TierApi.State.NOT_FOUND) {
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Player not found on CCTiers"), cx, this.height / 2, 0xFFFF7777);
            return;
        }
        if (st == TierApi.State.ERROR || entry.profile == null) {
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Could not reach the CCTiers API (" + entry.error + ")"), cx, this.height / 2 - 6, 0xFFFF7777);
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Check the API URL in /cctiers config"), cx, this.height / 2 + 6, 0xFFAAAAAA);
            return;
        }

        Profile p = entry.profile;
        String info = "Overall #" + (p.overall > 0 ? p.overall : "-") + "  |  " + p.points + " points"
                + (p.region.isEmpty() ? "" : "  |  " + p.region);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(info), cx, 26, 0xFFB2DDF7);

        int cols = this.width >= 330 ? 3 : 2;
        int gap = 4;
        int cardW = Math.min(104, (this.width - 16 - gap * (cols - 1)) / cols);
        int cardH = 30;
        int totalW = cols * cardW + (cols - 1) * gap;
        int left = cx - totalW / 2;
        int top = 44;

        GameMode[] modes = GameMode.values();
        for (int i = 0; i < modes.length; i++) {
            int x = left + (i % cols) * (cardW + gap);
            int y = top + (i / cols) * (cardH + gap);
            drawCard(ctx, modes[i], p.forMode(modes[i]), x, y, cardW, cardH);
        }
    }

    private void drawCard(DrawContext ctx, GameMode mode, Rank r, int x, int y, int w, int h) {
        int accent = r == null ? 0xFF444444 : (0xFF000000 | r.color());
        ctx.fill(x, y, x + w, y + h, 0xC0101418);
        ctx.fill(x, y, x + 2, y + h, accent);

        ctx.drawTextWithShadow(this.textRenderer, TierText.icon(mode), x + 6, y + 4, 0xFFFFFFFF);
        ctx.drawTextWithShadow(this.textRenderer, Text.literal(mode.display), x + 20, y + 4, 0xFFFFFFFF);

        if (r == null) {
            ctx.drawTextWithShadow(this.textRenderer, Text.literal("Unranked"), x + 6, y + 17, 0xFF777777);
            return;
        }
        ctx.drawTextWithShadow(this.textRenderer, Text.literal(r.label()).formatted(Formatting.BOLD), x + 6, y + 17, accent);
        String extra = r.retired() ? "retired" : "peak " + r.peakLabel();
        ctx.drawTextWithShadow(this.textRenderer, Text.literal(extra), x + 6 + this.textRenderer.getWidth(r.label()) + 8, y + 17, 0xFF999999);
    }
}
