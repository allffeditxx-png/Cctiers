package com.cctiers.ui;

import com.cctiers.CCTiersClient;
import com.cctiers.config.CCConfig;
import com.cctiers.data.TierApi;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public final class CCCommands {
    private CCCommands() {}

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher, CommandRegistryAccess access) {
        dispatcher.register(ClientCommandManager.literal("cctiers")
                .executes(ctx -> {
                    ctx.getSource().sendFeedback(Text.literal("CCTiers - /cctiers <player>, /cctiers config, /cctiers toggle, /cctiers refresh, /cctiers register"));
                    return 1;
                })
                .then(ClientCommandManager.literal("config").executes(ctx -> {
                    CCTiersClient.openNextTick(() -> new ConfigScreen(null));
                    return 1;
                }))
                .then(ClientCommandManager.literal("refresh").executes(ctx -> {
                    TierApi.clear();
                    ctx.getSource().sendFeedback(Text.literal("CCTiers: cache cleared, tiers will reload."));
                    return 1;
                }))
                .then(ClientCommandManager.literal("register").executes(ctx -> {
                    CCTiersClient.registerNow(MinecraftClient.getInstance());
                    ctx.getSource().sendFeedback(Text.literal("CCTiers: registering you on the API..."));
                    return 1;
                }))
                .then(ClientCommandManager.literal("toggle").executes(ctx -> {
                    CCConfig c = CCConfig.get();
                    c.enabled = !c.enabled;
                    CCConfig.save();
                    ctx.getSource().sendFeedback(Text.literal("CCTiers: " + (c.enabled ? "ON" : "OFF")));
                    return 1;
                }))
                .then(ClientCommandManager.argument("player", StringArgumentType.word())
                        .suggests((ctx, builder) -> CommandSource.suggestMatching(onlineNames(), builder))
                        .executes(ctx -> {
                            String name = StringArgumentType.getString(ctx, "player");
                            CCTiersClient.openNextTick(() -> new ProfileScreen(name));
                            return 1;
                        })));
    }

    private static List<String> onlineNames() {
        List<String> names = new ArrayList<>();
        ClientPlayNetworkHandler handler = MinecraftClient.getInstance().getNetworkHandler();
        if (handler != null) {
            for (PlayerListEntry e : handler.getPlayerList()) {
                names.add(e.getProfile().name());
            }
        }
        return names;
    }
}
