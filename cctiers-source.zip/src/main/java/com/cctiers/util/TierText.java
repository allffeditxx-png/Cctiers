package com.cctiers.util;

import com.cctiers.data.GameMode;
import com.cctiers.data.Rank;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import net.minecraft.text.Text;
import net.minecraft.text.TextCodecs;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;

import java.util.Optional;

public final class TierText {
    private TierText() {}

    private static final String FONT = "cctiers:gm";

    /** Builds "[icon] HT3 | " (icon optional). Falls back to plain coloured text if the font can't be used. */
    public static Text tag(Rank r, boolean icons) {
        JsonObject root = new JsonObject();
        root.addProperty("text", "");
        JsonArray extra = new JsonArray();

        if (icons) {
            JsonObject g = new JsonObject();
            g.addProperty("text", String.valueOf(r.mode().glyph()));
            g.addProperty("font", FONT);
            g.addProperty("color", "white");
            extra.add(g);
        }
        JsonObject tier = new JsonObject();
        tier.addProperty("text", " " + r.label());
        tier.addProperty("color", String.format("#%06X", r.color()));
        tier.addProperty("bold", true);
        extra.add(tier);

        JsonObject sep = new JsonObject();
        sep.addProperty("text", " | ");
        sep.addProperty("color", "dark_gray");
        sep.addProperty("bold", false);
        extra.add(sep);
        root.add("extra", extra);

        Optional<Text> parsed = TextCodecs.CODEC.parse(JsonOps.INSTANCE, root).result();
        if (parsed.isPresent()) return parsed.get();
        return plainTag(r);
    }

    private static Text plainTag(Rank r) {
        return Text.empty()
                .append(Text.literal(r.label()).styled(s -> s.withColor(TextColor.fromRgb(r.color()))))
                .append(Text.literal(" | ").formatted(Formatting.DARK_GRAY));
    }

    /** Just the gamemode icon, for the screens. Falls back to an empty text if the font can't be used. */
    public static Text icon(GameMode mode) {
        JsonObject g = new JsonObject();
        g.addProperty("text", String.valueOf(mode.glyph()));
        g.addProperty("font", FONT);
        g.addProperty("color", "white");
        Optional<Text> parsed = TextCodecs.CODEC.parse(JsonOps.INSTANCE, g).result();
        return parsed.orElse(Text.empty());
    }
}
