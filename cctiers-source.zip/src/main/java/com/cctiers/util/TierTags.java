package com.cctiers.util;

import com.cctiers.config.CCConfig;
import com.cctiers.data.TierApi;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

/** Called from the mixins. Returns null when the original text should be left alone. */
public final class TierTags {
    private TierTags() {}

    public static Text nametag(PlayerEntity player, Text original) {
        CCConfig c = CCConfig.get();
        if (!c.enabled || !c.showNametag || original == null) return null;
        // only players that exist on the client (skips the integrated server's copies)
        if (!(player instanceof AbstractClientPlayerEntity)) return null;
        if (player == MinecraftClient.getInstance().player && !c.showOwnTag) return null;
        return decorate(player.getName().getString(), original);
    }

    public static Text tab(PlayerListEntry entry, Text original) {
        CCConfig c = CCConfig.get();
        if (!c.enabled || !c.showTab) return null;
        String name = entry.getProfile().name();
        // getDisplayName is null for normal players, so fall back to the plain name
        return decorate(name, original != null ? original : Text.literal(name));
    }

    private static Text decorate(String name, Text original) {
        TierApi.Entry e = TierApi.get(name);
        if (e == null || e.state != TierApi.State.READY || e.profile == null) return null;
        Text tag = e.profile.tagFor(CCConfig.get());
        if (tag == null) return null;
        return Text.empty().append(tag).append(original);
    }

    // ---------------------------------------------------------------- chat

    /** Puts the tag right before the sender's name in a chat line. */
    public static Text chat(Text original) {
        CCConfig c = CCConfig.get();
        if (!c.enabled || !c.showChat || original == null) return null;
        ClientPlayNetworkHandler handler = MinecraftClient.getInstance().getNetworkHandler();
        if (handler == null) return null;

        String full = original.getString();
        int headerEnd = full.length();
        for (String sep : new String[]{"> ", ": ", "\u00BB "}) {
            int i = full.indexOf(sep);
            if (i >= 0 && i < headerEnd) headerEnd = i;
        }

        int bestIdx = -1;
        String bestName = null;
        Text bestTag = null;
        for (PlayerListEntry e : handler.getPlayerList()) {
            String name = e.getProfile().name();
            int idx = indexOfWord(full, name);
            if (idx < 0 || idx >= headerEnd) continue;
            if (bestIdx >= 0 && (idx > bestIdx || (idx == bestIdx && name.length() <= bestName.length()))) continue;
            TierApi.Entry en = TierApi.get(name);
            if (en == null || en.state != TierApi.State.READY || en.profile == null) continue;
            Text tag = en.profile.tagFor(c);
            if (tag == null) continue;
            bestIdx = idx;
            bestName = name;
            bestTag = tag;
        }
        if (bestTag == null) return null;
        return insertAt(original, bestIdx, bestTag);
    }

    private static int indexOfWord(String s, String word) {
        int from = 0;
        while (true) {
            int i = s.indexOf(word, from);
            if (i < 0) return -1;
            boolean before = i == 0 || !isNameChar(s.charAt(i - 1));
            int end = i + word.length();
            boolean after = end >= s.length() || !isNameChar(s.charAt(end));
            if (before && after) return i;
            from = i + 1;
        }
    }

    private static boolean isNameChar(char ch) {
        return Character.isLetterOrDigit(ch) || ch == '_';
    }

    /** Rebuilds the text with tag inserted at character offset idx, keeping every chunk's style. */
    private static Text insertAt(Text original, int idx, Text tag) {
        MutableText out = Text.empty();
        int[] pos = {0};
        boolean[] done = {false};
        original.<Object>visit((style, str) -> {
            int start = pos[0];
            int end = start + str.length();
            if (!done[0] && idx >= start && idx < end) {
                int cut = idx - start;
                if (cut > 0) out.append(Text.literal(str.substring(0, cut)).setStyle(style));
                out.append(tag);
                out.append(Text.literal(str.substring(cut)).setStyle(style));
                done[0] = true;
            } else if (!str.isEmpty()) {
                out.append(Text.literal(str).setStyle(style));
            }
            pos[0] = end;
            return java.util.Optional.empty();
        }, Style.EMPTY);
        return done[0] ? out : original;
    }
}
