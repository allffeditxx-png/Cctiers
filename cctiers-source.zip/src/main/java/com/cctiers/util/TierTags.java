package com.cctiers.util;

import com.cctiers.config.CCConfig;
import com.cctiers.data.Profile;
import com.cctiers.data.TierApi;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

import java.util.Optional;

/** Called from the mixins. Returns null when the original text should be left alone. */
public final class TierTags {
    private TierTags() {}

    public static Text nametag(PlayerEntity player, Text original) {
        CCConfig c = CCConfig.get();
        if (!c.enabled || !c.showNametag || original == null) return null;
        // only players that exist on the client (skips the integrated server's copies)
        if (!(player instanceof AbstractClientPlayerEntity)) return null;
        if (player == MinecraftClient.getInstance().player && !c.showOwnTag) return null;
        return decorate(player.getName().getString(), original);
    }

    public static Text tab(PlayerListEntry entry, Text original) {
        CCConfig c = CCConfig.get();
        if (!c.enabled || !c.showTab) return null;
        String name = entry.getProfile().name();
        // getDisplayName is null for normal players, so fall back to the plain name
        return decorate(name, original != null ? original : Text.literal(name));
    }

    private static Profile.Tags tagsOf(String name) {
        TierApi.Entry e = TierApi.get(name);
        if (e == null || e.state != TierApi.State.READY || e.profile == null) return null;
        return e.profile.tagsFor(CCConfig.get());
    }

    private static Text decorate(String name, Text original) {
        Profile.Tags t = tagsOf(name);
        if (t == null) return null;
        MutableText out = Text.empty().append(t.prefix()).append(original);
        if (t.suffix() != null) out.append(t.suffix());
        return out;
    }

    // ---------------------------------------------------------------- chat

    /** Puts the tags around the sender's name in a chat line. */
    public static Text chat(Text original) {
        CCConfig c = CCConfig.get();
        if (!c.enabled || !c.showChat || original == null) return null;
        ClientPlayNetworkHandler handler = MinecraftClient.getInstance().getNetworkHandler();
        if (handler == null) return null;

        String full = original.getString();
        int headerEnd = full.length();
        for (String sep : new String[]{"> ", ": ", "\u00BB "}) {
            int i = full.indexOf(sep);
            if (i >= 0 && i < headerEnd) headerEnd = i;
        }

        int bestIdx = -1;
        String bestName = null;
        Profile.Tags bestTags = null;
        for (PlayerListEntry e : handler.getPlayerList()) {
            String name = e.getProfile().name();
            int idx = indexOfWord(full, name);
            if (idx < 0 || idx >= headerEnd) continue;
            if (bestIdx >= 0 && (idx > bestIdx || (idx == bestIdx && name.length() <= bestName.length()))) continue;
            Profile.Tags tags = tagsOf(name);
            if (tags == null) continue;
            bestIdx = idx;
            bestName = name;
            bestTags = tags;
        }
        if (bestTags == null) return null;
        return insertAt(original, bestIdx, bestTags.prefix(), bestIdx + bestName.length(), bestTags.suffix());
    }

    private static int indexOfWord(String s, String word) {
        int from = 0;
        while (true) {
            int i = s.indexOf(word, from);
            if (i < 0) return -1;
            boolean before = i == 0 || !isNameChar(s.charAt(i - 1));
            int end = i + word.length();
            boolean after = end >= s.length() || !isNameChar(s.charAt(end));
            if (before && after) return i;
            from = i + 1;
        }
    }

    private static boolean isNameChar(char ch) {
        return Character.isLetterOrDigit(ch) || ch == '_';
    }

    /** Rebuilds the text with t1 inserted at character offset idx1 and t2 (may be null) at idx2, keeping every chunk's style. */
    private static Text insertAt(Text original, int idx1, Text t1, int idx2, Text t2) {
        MutableText out = Text.empty();
        int[] pos = {0};
        int[] stage = {0}; // 0 = t1 still to insert, 1 = t2 still to insert, 2 = done
        original.<Object>visit((style, str) -> {
            int start = pos[0];
            int end = start + str.length();
            int cursor = 0;
            while (stage[0] < 2) {
                Text t = stage[0] == 0 ? t1 : t2;
                int off = stage[0] == 0 ? idx1 : idx2;
                if (t == null) {
                    stage[0] = 2;
                    break;
                }
                if (off >= end) break;
                int cut = Math.max(off - start, cursor);
                if (cut > cursor) out.append(Text.literal(str.substring(cursor, cut)).setStyle(style));
                cursor = cut;
                out.append(t);
                stage[0]++;
            }
            if (cursor < str.length()) out.append(Text.literal(str.substring(cursor)).setStyle(style));
            pos[0] = end;
            return Optional.empty();
        }, Style.EMPTY);
        if (stage[0] == 0) out.append(t1);
        if (stage[0] <= 1 && t2 != null) out.append(t2);
        return out;
    }
}
