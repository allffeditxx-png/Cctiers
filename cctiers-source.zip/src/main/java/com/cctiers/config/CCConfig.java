package com.cctiers.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public final class CCConfig {
    public boolean enabled = true;
    public boolean showNametag = true;
    public boolean showTab = true;
    public boolean showChat = true;
    public boolean showIcons = true;
    public boolean showOwnTag = true;
    /** "highest" or a gamemode id such as "crystal", "sword", "neth_pot". */
    public String displayMode = "highest";
    /** Base URL of the CCTiers API (no trailing slash needed). */
    public String apiBase = "https://api.hypen9.qzz.io";
    /** On first use the mod registers the local player (name + uuid) on the API: POST {apiBase}/players */
    public boolean registerPlayer = true;
    public boolean registered = false;
    public int cacheMinutes = 10;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static CCConfig instance = new CCConfig();

    public static CCConfig get() {
        return instance;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("cctiers.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                CCConfig c = GSON.fromJson(Files.readString(f), CCConfig.class);
                if (c != null) instance = c;
            }
        } catch (Exception ignored) {
        }
        save();
    }

    public static void save() {
        try {
            Files.writeString(file(), GSON.toJson(instance));
        } catch (Exception ignored) {
        }
    }
}
