package com.cctiers.data;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses the CCTiers /players list:
 *   { "ayushxdp": { "username": "AyushXDP", "region": "AS", "tiers": { "vanilla": "HT4", "sword": "LT3" }, ... }, ... }
 * Also accepts an array of such players, {"players": ...}, and "rankings": { mode: {tier,pos} } style players.
 */
public final class ProfileParser {
    private ProfileParser() {}

    private static final Pattern TIER = Pattern.compile("(?i)(h|high|l|low)\\D*([1-5])");

    /** All players, keyed by lower-case username, with overall ranks computed from points. */
    public static Map<String, Profile> parseAll(String body) {
        JsonElement root = JsonParser.parseString(body);
        List<Profile> list = new ArrayList<>();
        collect(root, null, list);

        int[] points = new int[list.size()];
        for (int i = 0; i < points.length; i++) points[i] = list.get(i).points;

        Map<String, Profile> out = new HashMap<>();
        for (Profile p : list) {
            int overall = 0;
            if (p.points > 0) {
                int higher = 0;
                for (int pt : points) if (pt > p.points) higher++;
                overall = higher + 1;
            }
            out.put(p.name.toLowerCase(Locale.ROOT), p.withOverall(overall));
        }
        return out;
    }

    private static void collect(JsonElement el, String key, List<Profile> out) {
        if (el == null || el.isJsonNull()) return;
        if (el.isJsonArray()) {
            for (JsonElement e : el.getAsJsonArray()) collect(e, null, out);
            return;
        }
        if (!el.isJsonObject()) return;
        JsonObject o = el.getAsJsonObject();

        if (looksLikePlayer(o)) {
            Profile p = fromObject(o, key);
            if (p != null) out.add(p);
            return;
        }
        for (Map.Entry<String, JsonElement> e : o.entrySet()) {
            JsonElement v = e.getValue();
            if (v != null && (v.isJsonObject() || v.isJsonArray())) collect(v, e.getKey(), out);
        }
    }

    private static boolean looksLikePlayer(JsonObject o) {
        return o.has("tiers") || o.has("rankings") || o.has("username");
    }

    private static Profile fromObject(JsonObject o, String fallbackName) {
        String name = str(o, "username", "name", "nick", "player", "ign");
        if (name == null) name = fallbackName;
        if (name == null || name.isEmpty()) return null;
        String region = str(o, "region", "country");

        List<Rank> ranks = new ArrayList<>();
        JsonElement container = null;
        for (String k : new String[]{"tiers", "rankings", "gamemodes", "modes"}) {
            JsonElement c = o.get(k);
            if (c != null && (c.isJsonObject() || c.isJsonArray())) {
                container = c;
                break;
            }
        }
        if (container != null && container.isJsonObject()) {
            for (Map.Entry<String, JsonElement> e : container.getAsJsonObject().entrySet()) {
                add(ranks, GameMode.fromKey(e.getKey()), e.getValue());
            }
        } else if (container != null) {
            for (JsonElement e : container.getAsJsonArray()) {
                if (!e.isJsonObject()) continue;
                JsonObject eo = e.getAsJsonObject();
                add(ranks, GameMode.fromKey(str(eo, "gamemode", "mode", "kit", "name", "id")), eo);
            }
        }

        int points = num(o, -1, "points", "score", "total_points");
        if (points < 0) {
            points = 0;
            for (Rank r : ranks) points += r.points();
        }
        return new Profile(name, region == null ? "" : region, points, 0, ranks);
    }

    private static void add(List<Rank> out, GameMode mode, JsonElement v) {
        if (mode == null || v == null || v.isJsonNull()) return;
        for (Rank r : out) if (r.mode() == mode) return;
        Rank rank = parseRank(mode, v);
        if (rank != null) out.add(rank);
    }

    private static Rank parseRank(GameMode mode, JsonElement v) {
        if (v.isJsonPrimitive()) {
            int[] t = tierFrom(v);
            if (t == null) return null; // "UNRANKED" etc.
            boolean high = t[1] != 0;
            return new Rank(mode, t[0], high, t[0], high, false);
        }
        if (!v.isJsonObject()) return null;
        JsonObject o = v.getAsJsonObject();
        int[] t = tierFrom(first(o, "tier", "rank", "level", "current", "value"));
        if (t == null) return null;
        boolean high = t[1] == -1 ? posHigh(o, "pos", "position") : t[1] == 1;

        int peakTier = t[0];
        boolean peakHigh = high;
        int[] p = tierFrom(first(o, "peak_tier", "peakTier", "peak"));
        if (p != null) {
            peakTier = p[0];
            peakHigh = p[1] == -1 ? posHigh(o, "peak_pos", "peakPos") : p[1] == 1;
        }
        boolean retired = o.has("retired") && o.get("retired").isJsonPrimitive() && o.get("retired").getAsBoolean();
        return new Rank(mode, t[0], high, peakTier, peakHigh, retired);
    }

    private static boolean posHigh(JsonObject o, String... keys) {
        for (String k : keys) {
            JsonElement e = o.get(k);
            if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) return e.getAsInt() == 0;
        }
        for (String k : new String[]{"high", "is_high", "ht"}) {
            JsonElement e = o.get(k);
            if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isBoolean()) return e.getAsBoolean();
        }
        return true;
    }

    /** {tier, highFlag}: highFlag 1 = HT, 0 = LT, -1 = unknown. Null = unranked/invalid. */
    private static int[] tierFrom(JsonElement el) {
        if (el == null || el.isJsonNull() || !el.isJsonPrimitive()) return null;
        if (el.getAsJsonPrimitive().isNumber()) {
            int n = el.getAsInt();
            return (n >= 1 && n <= 5) ? new int[]{n, -1} : null;
        }
        String s = el.getAsString().trim();
        Matcher m = TIER.matcher(s);
        if (m.find()) {
            boolean high = Character.toLowerCase(m.group(1).charAt(0)) == 'h';
            return new int[]{Integer.parseInt(m.group(2)), high ? 1 : 0};
        }
        try {
            int n = Integer.parseInt(s);
            return (n >= 1 && n <= 5) ? new int[]{n, -1} : null;
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private static JsonElement first(JsonObject o, String... keys) {
        for (String k : keys) {
            JsonElement e = o.get(k);
            if (e != null && !e.isJsonNull()) return e;
        }
        return null;
    }

    private static String str(JsonObject o, String... keys) {
        JsonElement e = first(o, keys);
        return (e != null && e.isJsonPrimitive()) ? e.getAsString() : null;
    }

    private static int num(JsonObject o, int def, String... keys) {
        JsonElement e = first(o, keys);
        if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) return e.getAsInt();
        return def;
    }
}
