package com.cctiers.data;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Lenient parser. It understands the common tier-list API shapes:
 *   { "name": "...", "region": "NA", "points": 300, "overall": 1,
 *     "rankings": { "crystal": { "tier": 1, "pos": 0, "peak_tier": 1, "peak_pos": 0, "retired": false } } }
 *   { "name": "...", "tiers": { "sword": "HT3", "crystal": "LT2" } }
 *   [ { "name": "...", ... }, ... ]   (a player list - the right player is picked by name)
 */
public final class ProfileParser {
    private ProfileParser() {}

    private static final Pattern TIER = Pattern.compile("(?i)(h|high|l|low)\\D*([1-5])");

    /** Returns null if the player is not in the response. Throws if the JSON is unusable. */
    public static Profile parse(String body, String wantedName) {
        JsonElement root = JsonParser.parseString(body);
        JsonObject player = findPlayer(root, wantedName);
        if (player == null) return null;
        return fromObject(player, wantedName);
    }

    private static JsonObject findPlayer(JsonElement root, String wantedName) {
        if (root == null || root.isJsonNull()) return null;
        if (root.isJsonArray()) return pickFromArray(root.getAsJsonArray(), wantedName);
        if (!root.isJsonObject()) return null;
        JsonObject o = root.getAsJsonObject();
        for (String wrap : new String[]{"players", "data", "results", "player", "profile"}) {
            JsonElement inner = o.get(wrap);
            if (inner == null || inner.isJsonNull()) continue;
            if (inner.isJsonArray()) return pickFromArray(inner.getAsJsonArray(), wantedName);
            if (inner.isJsonObject()) {
                JsonObject io = inner.getAsJsonObject();
                if (!looksLikePlayer(o) || io.has("name") || io.has("username")) return findPlayer(io, wantedName);
            }
        }
        if (o.has("error") && !looksLikePlayer(o)) return null;
        return o;
    }

    private static boolean looksLikePlayer(JsonObject o) {
        return o.has("name") || o.has("username") || o.has("rankings") || o.has("tiers");
    }

    private static JsonObject pickFromArray(JsonArray arr, String wantedName) {
        for (JsonElement e : arr) {
            if (!e.isJsonObject()) continue;
            JsonObject o = e.getAsJsonObject();
            String n = str(o, "name", "username", "nick", "player", "ign");
            if (n != null && n.equalsIgnoreCase(wantedName)) return o;
        }
        return null;
    }

    private static Profile fromObject(JsonObject o, String fallbackName) {
        String name = str(o, "name", "username", "nick", "player", "ign");
        if (name == null) name = fallbackName;
        String region = str(o, "region", "country");
        int points = num(o, 0, "points", "score", "total_points");
        int overall = num(o, 0, "overall", "rank", "position", "placement");

        List<Rank> ranks = new ArrayList<>();
        JsonElement container = null;
        for (String k : new String[]{"rankings", "tiers", "gamemodes", "modes", "gamemode_tiers", "stats", "kits"}) {
            JsonElement c = o.get(k);
            if (c != null && (c.isJsonObject() || c.isJsonArray())) {
                container = c;
                break;
            }
        }

        if (container != null && container.isJsonObject()) {
            for (Map.Entry<String, JsonElement> e : container.getAsJsonObject().entrySet()) {
                add(ranks, GameMode.fromKey(e.getKey()), e.getValue());
            }
        } else if (container != null) {
            for (JsonElement e : container.getAsJsonArray()) {
                if (!e.isJsonObject()) continue;
                JsonObject eo = e.getAsJsonObject();
                String key = str(eo, "gamemode", "mode", "kit", "name", "id");
                add(ranks, GameMode.fromKey(key), eo);
            }
        } else {
            // gamemodes directly on the player object
            for (Map.Entry<String, JsonElement> e : o.entrySet()) {
                GameMode m = GameMode.fromKey(e.getKey());
                if (m != null) add(ranks, m, e.getValue());
            }
        }
        return new Profile(name, region == null ? "" : region, points, overall, ranks);
    }

    private static void add(List<Rank> out, GameMode mode, JsonElement v) {
        if (mode == null || v == null || v.isJsonNull()) return;
        for (Rank r : out) if (r.mode() == mode) return;
        Rank rank = parseRank(mode, v);
        if (rank != null) out.add(rank);
    }

    private static Rank parseRank(GameMode mode, JsonElement v) {
        if (v.isJsonPrimitive()) {
            int[] t = tierFrom(v);
            if (t == null) return null;
            boolean high = t[1] != 0;
            return new Rank(mode, t[0], high, t[0], high, false);
        }
        if (!v.isJsonObject()) return null;
        JsonObject o = v.getAsJsonObject();
        int[] t = tierFrom(first(o, "tier", "rank", "level", "current", "value"));
        if (t == null) return null;
        boolean high = t[1] == -1 ? posHigh(o, "pos", "position") : t[1] == 1;

        int peakTier = t[0];
        boolean peakHigh = high;
        int[] p = tierFrom(first(o, "peak_tier", "peakTier", "peak"));
        if (p != null) {
            peakTier = p[0];
            peakHigh = p[1] == -1 ? posHigh(o, "peak_pos", "peakPos") : p[1] == 1;
        }
        boolean retired = o.has("retired") && o.get("retired").isJsonPrimitive() && o.get("retired").getAsBoolean();
        return new Rank(mode, t[0], high, peakTier, peakHigh, retired);
    }

    private static boolean posHigh(JsonObject o, String... keys) {
        for (String k : keys) {
            JsonElement e = o.get(k);
            if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) return e.getAsInt() == 0;
        }
        for (String k : new String[]{"high", "is_high", "ht"}) {
            JsonElement e = o.get(k);
            if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isBoolean()) return e.getAsBoolean();
        }
        return true;
    }

    /** {tier, highFlag} where highFlag is 1 (HT), 0 (LT) or -1 (unknown). Null = unranked/invalid. */
    private static int[] tierFrom(JsonElement el) {
        if (el == null || el.isJsonNull() || !el.isJsonPrimitive()) return null;
        if (el.getAsJsonPrimitive().isNumber()) {
            int n = el.getAsInt();
            return (n >= 1 && n <= 5) ? new int[]{n, -1} : null;
        }
        String s = el.getAsString().trim();
        Matcher m = TIER.matcher(s);
        if (m.find()) {
            boolean high = Character.toLowerCase(m.group(1).charAt(0)) == 'h';
            return new int[]{Integer.parseInt(m.group(2)), high ? 1 : 0};
        }
        try {
            int n = Integer.parseInt(s);
            return (n >= 1 && n <= 5) ? new int[]{n, -1} : null;
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private static JsonElement first(JsonObject o, String... keys) {
        for (String k : keys) {
            JsonElement e = o.get(k);
            if (e != null && !e.isJsonNull()) return e;
        }
        return null;
    }

    private static String str(JsonObject o, String... keys) {
        JsonElement e = first(o, keys);
        return (e != null && e.isJsonPrimitive()) ? e.getAsString() : null;
    }

    private static int num(JsonObject o, int def, String... keys) {
        JsonElement e = first(o, keys);
        if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) return e.getAsInt();
        return def;
    }
}
