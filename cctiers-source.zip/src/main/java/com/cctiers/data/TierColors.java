package com.cctiers.data;

public final class TierColors {
    private TierColors() {}

    public static int of(int tier, boolean high) {
        return switch (tier) {
            case 1 -> high ? 0xF5CE4D : 0xE3B93A;
            case 2 -> high ? 0xD5DDE6 : 0xAAB7C4;
            case 3 -> high ? 0xD48A5A : 0xB06453;
            case 4 -> high ? 0xC9424F : 0xA0323D;
            default -> high ? 0xCFCED3 : 0xA7A6AD;
        };
    }
}
