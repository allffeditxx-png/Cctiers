package com.cctiers.data;

public final class TierColors {
    private TierColors() {}

    public static int of(int tier, boolean high) {
        return switch (tier) {
            case 1 -> high ? 0xE8BA3A : 0xD5B355; // gold / pale gold
            case 2 -> high ? 0xC4D3E7 : 0xA0A7B2; // light silver-blue / grey
            case 3 -> high ? 0xF89F5A : 0xC67842; // orange / bronze
            case 4 -> high ? 0xB1749A : 0x655879; // pinkish purple / dark purple
            default -> high ? 0x8F82A8 : 0x655879; // light purple / dark purple
        };
    }
}
