package com.cctiers.data;

import com.cctiers.config.CCConfig;
import com.google.gson.JsonObject;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/**
 * Downloads the whole player list from the CCTiers API once (GET /players), keeps it in memory and
 * refreshes it every few minutes. get() never blocks - it returns whatever is known right now.
 * First use of the mod also registers the local player (POST /players).
 */
public final class TierApi {
    private TierApi() {}

    /** The API is fixed. */
    public static final String URL = "https://api.hypen9.qzz.io/players";

    public enum State { LOADING, READY, NOT_FOUND, ERROR }

    public static final class Entry {
        public final State state;
        public final Profile profile;
        public final String error;

        Entry(State state, Profile profile, String error) {
            this.state = state;
            this.profile = profile;
            this.error = error;
        }
    }

    private static final Entry LOADING = new Entry(State.LOADING, null, "");
    private static final Entry NOT_FOUND = new Entry(State.NOT_FOUND, null, "");

    private static final Pattern VALID_NAME = Pattern.compile("^[A-Za-z0-9_]{3,16}$");
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
    private static final ExecutorService POOL = Executors.newFixedThreadPool(2, r -> {
        Thread t = new Thread(r, "cctiers-net");
        t.setDaemon(true);
        return t;
    });
    private static final Map<String, Entry> VIEWS = new ConcurrentHashMap<>();

    private static volatile Map<String, Profile> players = null;
    private static volatile long loadedAt = 0L;
    private static volatile long lastAttempt = 0L;
    private static volatile boolean loading = false;
    private static volatile String loadError = "";

    /** Entry for a player (starts/refreshes the download when needed). Null for names that can't be real players. */
    public static Entry get(String name) {
        if (name == null || !VALID_NAME.matcher(name).matches()) return null;
        ensureLoaded();
        Map<String, Profile> map = players;
        if (map == null) {
            if (!loading && !loadError.isEmpty()) return new Entry(State.ERROR, null, loadError);
            return LOADING;
        }
        String key = name.toLowerCase(Locale.ROOT);
        return VIEWS.computeIfAbsent(key, k -> {
            Profile p = map.get(k);
            return p == null ? NOT_FOUND : new Entry(State.READY, p, "");
        });
    }

    /** Starts a download if there is no data yet or it is older than the cache time. */
    public static void ensureLoaded() {
        if (loading) return;
        long now = System.currentTimeMillis();
        long ttl = Math.max(1, CCConfig.get().cacheMinutes) * 60_000L;
        boolean need;
        if (players == null) need = now - lastAttempt > 30_000L;
        else need = now - loadedAt > ttl;
        if (need) load();
    }

    /** Download again right now (keeps showing the old data until the new data arrives). */
    public static void refresh() {
        if (!loading) {
            loadedAt = 0L;
            lastAttempt = 0L;
            load();
        }
    }

    /** Forget everything and download again. */
    public static void clear() {
        players = null;
        VIEWS.clear();
        loadedAt = 0L;
        lastAttempt = 0L;
        loadError = "";
    }

    private static synchronized void load() {
        if (loading) return;
        loading = true;
        lastAttempt = System.currentTimeMillis();
        POOL.submit(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder(URI.create(URL))
                        .timeout(Duration.ofSeconds(20))
                        .header("Accept", "application/json")
                        .header("User-Agent", "CCTiers/1.0 (by AyushXDP)")
                        .GET().build();
                HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
                if (res.statusCode() < 200 || res.statusCode() >= 300) {
                    loadError = "HTTP " + res.statusCode();
                } else {
                    Map<String, Profile> parsed = ProfileParser.parseAll(res.body());
                    players = parsed;
                    VIEWS.clear();
                    loadedAt = System.currentTimeMillis();
                    loadError = "";
                }
            } catch (Exception ex) {
                loadError = ex.getClass().getSimpleName();
            } finally {
                loading = false;
            }
        });
    }

    /** Registers the local player on the API (POST /players). done gets true on success or "already exists". */
    public static void register(String name, String uuid, Consumer<Boolean> done) {
        POOL.submit(() -> {
            boolean ok = false;
            try {
                JsonObject body = new JsonObject();
                body.addProperty("username", name);
                body.addProperty("name", name);
                body.addProperty("uuid", uuid);
                body.addProperty("source", "cctiers-mod");
                HttpRequest req = HttpRequest.newBuilder(URI.create(URL))
                        .timeout(Duration.ofSeconds(10))
                        .header("Content-Type", "application/json")
                        .header("Accept", "application/json")
                        .header("User-Agent", "CCTiers/1.0 (by AyushXDP)")
                        .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                        .build();
                int code = HTTP.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8)).statusCode();
                ok = (code >= 200 && code < 300) || code == 409;
            } catch (Exception ignored) {
            }
            done.accept(ok);
        });
    }
}
