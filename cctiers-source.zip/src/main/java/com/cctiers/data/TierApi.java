package com.cctiers.data;

import com.cctiers.config.CCConfig;
import com.google.gson.JsonObject;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/**
 * Async, cached lookups against the CCTiers API.
 *   GET  {base}/players/{name}   one player (falls back to the list below on 404)
 *   GET  {base}/players          list of players
 *   POST {base}/players          register a player {"name","uuid","source"}
 * get() never blocks - it returns whatever is known right now.
 */
public final class TierApi {
    private TierApi() {}

    public enum State { LOADING, READY, NOT_FOUND, ERROR }

    public static final class Entry {
        public volatile State state = State.LOADING;
        public volatile Profile profile;
        public volatile String error = "";
        volatile long fetchedAt = 0L;
        volatile boolean fetching = false;
    }

    private static final Pattern VALID_NAME = Pattern.compile("^[A-Za-z0-9_]{3,16}$");
    private static final Map<String, Entry> CACHE = new ConcurrentHashMap<>();
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
    private static final ExecutorService POOL = Executors.newFixedThreadPool(3, r -> {
        Thread t = new Thread(r, "cctiers-net");
        t.setDaemon(true);
        return t;
    });

    private static String listBody;
    private static long listAt = 0L;

    /** Cached entry (starting a fetch if needed). Returns null for names that can't be real players. */
    public static Entry get(String name) {
        if (name == null || !VALID_NAME.matcher(name).matches()) return null;
        String key = name.toLowerCase(Locale.ROOT);
        Entry e = CACHE.computeIfAbsent(key, k -> new Entry());
        long now = System.currentTimeMillis();
        if (!e.fetching) {
            long ttl = Math.max(1, CCConfig.get().cacheMinutes) * 60_000L;
            boolean stale = switch (e.state) {
                case LOADING -> e.fetchedAt == 0L;
                case READY, NOT_FOUND -> now - e.fetchedAt > ttl;
                case ERROR -> now - e.fetchedAt > 60_000L;
            };
            if (stale) fetch(e, name);
        }
        return e;
    }

    /** Fresh lookup, used by the search screen. */
    public static Entry forceFetch(String name) {
        String key = name.toLowerCase(Locale.ROOT);
        Entry e = CACHE.computeIfAbsent(key, k -> new Entry());
        if (!e.fetching) fetch(e, name);
        return e;
    }

    public static void clear() {
        CACHE.clear();
        synchronized (TierApi.class) {
            listBody = null;
            listAt = 0L;
        }
    }

    private static void fetch(Entry e, String name) {
        e.fetching = true;
        POOL.submit(() -> {
            try {
                String enc = URLEncoder.encode(name, StandardCharsets.UTF_8);
                HttpResponse<String> res = send(base() + "/players/" + enc);
                int code = res.statusCode();
                Profile p = null;
                boolean failed = false;
                if (code >= 200 && code < 300) {
                    p = ProfileParser.parse(res.body(), name);
                } else if (code != 404 && code != 405) {
                    failed = true;
                    e.error = "HTTP " + code;
                }
                if (p == null && !failed) {
                    String list = listBody();
                    if (list != null) p = ProfileParser.parse(list, name);
                }
                if (failed) {
                    e.state = State.ERROR;
                } else if (p == null) {
                    e.profile = null;
                    e.state = State.NOT_FOUND;
                } else {
                    e.profile = p;
                    e.state = State.READY;
                }
            } catch (Exception ex) {
                e.error = ex.getClass().getSimpleName();
                e.state = State.ERROR;
            } finally {
                e.fetchedAt = System.currentTimeMillis();
                e.fetching = false;
            }
        });
    }

    /** The /players list, cached for a minute so unknown players don't hammer the API. */
    private static String listBody() {
        synchronized (TierApi.class) {
            long now = System.currentTimeMillis();
            if (now - listAt < 60_000L) return listBody;
            listAt = now;
            try {
                HttpResponse<String> res = send(base() + "/players");
                listBody = (res.statusCode() >= 200 && res.statusCode() < 300) ? res.body() : null;
            } catch (Exception ex) {
                listBody = null;
            }
            return listBody;
        }
    }

    /** Registers the local player on the API (POST /players). done gets true on success or "already exists". */
    public static void register(String name, String uuid, Consumer<Boolean> done) {
        POOL.submit(() -> {
            boolean ok = false;
            try {
                JsonObject body = new JsonObject();
                body.addProperty("name", name);
                body.addProperty("uuid", uuid);
                body.addProperty("source", "cctiers-mod");
                HttpRequest req = HttpRequest.newBuilder(URI.create(base() + "/players"))
                        .timeout(Duration.ofSeconds(10))
                        .header("Content-Type", "application/json")
                        .header("Accept", "application/json")
                        .header("User-Agent", "CCTiers/1.0 (by AyushXDP)")
                        .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                        .build();
                int code = HTTP.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8)).statusCode();
                ok = (code >= 200 && code < 300) || code == 409;
            } catch (Exception ignored) {
            }
            done.accept(ok);
        });
    }

    private static HttpResponse<String> send(String url) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(10))
                .header("Accept", "application/json")
                .header("User-Agent", "CCTiers/1.0 (by AyushXDP)")
                .GET().build();
        return HTTP.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
    }

    private static String base() {
        String b = CCConfig.get().apiBase.trim();
        while (b.endsWith("/")) b = b.substring(0, b.length() - 1);
        return b;
    }
}
