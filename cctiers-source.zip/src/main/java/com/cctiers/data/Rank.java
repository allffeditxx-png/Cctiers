package com.cctiers.data;

/** One player's rank in one gamemode. tier is 1..5, high = HT (true) or LT (false). */
public record Rank(GameMode mode, int tier, boolean high, int peakTier, boolean peakHigh, boolean retired) {

    public String label() {
        return (high ? "HT" : "LT") + tier;
    }

    public String peakLabel() {
        return (peakHigh ? "HT" : "LT") + peakTier;
    }

    /** Lower is better. HT1 = 2, LT1 = 3, HT2 = 4 ... */
    public int score() {
        return tier * 2 + (high ? 0 : 1);
    }

    public int color() {
        if (retired) return 0x6B6B6B;
        return TierColors.of(tier, high);
    }
}
