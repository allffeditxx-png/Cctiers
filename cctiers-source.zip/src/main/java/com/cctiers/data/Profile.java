package com.cctiers.data;

import com.cctiers.config.CCConfig;
import com.cctiers.util.TierText;
import net.minecraft.text.Text;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class Profile {
    /** "[icon] HT4 | " in front of the name, " | LT3 [icon]" behind it (suffix may be null). */
    public record Tags(Text prefix, Text suffix) {}

    public final String name;
    public final String region;
    public final int points;
    public final int overall;
    public final List<Rank> ranks;

    private final Map<String, Tags> tagCache = new ConcurrentHashMap<>();

    public Profile(String name, String region, int points, int overall, List<Rank> ranks) {
        this.name = name;
        this.region = region;
        this.points = points;
        this.overall = overall;
        this.ranks = ranks;
    }

    public Profile withOverall(int newOverall) {
        return new Profile(name, region, points, newOverall, ranks);
    }

    public Rank forMode(GameMode mode) {
        for (Rank r : ranks) {
            if (r.mode() == mode) return r;
        }
        return null;
    }

    /** Best rank (HT1 > LT1 > HT2 ...). */
    public Rank best() {
        return ranks.stream().min(Comparator.comparingInt(Rank::score)).orElse(null);
    }

    public Tags tagsFor(CCConfig cfg) {
        Rank primary = null;
        GameMode wanted = GameMode.fromId(cfg.displayMode);
        if (wanted != null) primary = forMode(wanted);
        if (primary == null) primary = best();
        if (primary == null) return null;

        Rank secondary = null;
        if (cfg.showSecondTier) {
            for (Rank r : ranks) {
                if (r.mode() == primary.mode()) continue;
                if (secondary == null || r.score() < secondary.score()) secondary = r;
            }
        }

        final Rank p = primary;
        final Rank s = secondary;
        final boolean icons = cfg.showIcons;
        String key = p.mode().id + p.label() + "|" + (s == null ? "-" : s.mode().id + s.label()) + "|" + icons;
        return tagCache.computeIfAbsent(key, k ->
                new Tags(TierText.prefix(p, icons), s == null ? null : TierText.suffix(s, icons)));
    }
}
