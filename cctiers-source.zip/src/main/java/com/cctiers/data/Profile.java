package com.cctiers.data;

import com.cctiers.config.CCConfig;
import com.cctiers.util.TierText;
import net.minecraft.text.Text;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class Profile {
    public final String name;
    public final String region;
    public final int points;
    public final int overall;
    public final List<Rank> ranks;

    private final Map<String, Text> tagCache = new ConcurrentHashMap<>();

    public Profile(String name, String region, int points, int overall, List<Rank> ranks) {
        this.name = name;
        this.region = region;
        this.points = points;
        this.overall = overall;
        this.ranks = ranks;
    }

    public Rank forMode(GameMode mode) {
        for (Rank r : ranks) {
            if (r.mode() == mode) return r;
        }
        return null;
    }

    /** Best active rank (retired ranks only count if nothing else exists). */
    public Rank best() {
        return ranks.stream()
                .min(Comparator.<Rank>comparingInt(r -> r.retired() ? 1 : 0).thenComparingInt(Rank::score))
                .orElse(null);
    }

    /** The "[icon] HT3 | " prefix according to the config, or null if the player has no ranks. */
    public Text tagFor(CCConfig cfg) {
        Rank r = null;
        GameMode wanted = GameMode.fromId(cfg.displayMode);
        if (wanted != null) r = forMode(wanted);
        if (r == null) r = best();
        if (r == null) return null;
        final Rank chosen = r;
        final boolean icons = cfg.showIcons;
        String key = chosen.mode().id + ":" + chosen.label() + ":" + chosen.retired() + ":" + icons;
        return tagCache.computeIfAbsent(key, k -> TierText.tag(chosen, icons));
    }
}
