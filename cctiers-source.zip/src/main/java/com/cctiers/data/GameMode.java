package com.cctiers.data;

import java.util.Locale;

/** Gamemodes used by the CCTiers API. Order = order of the cards on the profile screen. */
public enum GameMode {
    VANILLA("vanilla", "Vanilla"),
    CRYSTAL("crystal", "Crystal"),
    UHC("uhc", "UHC"),
    POT("pot", "Pot"),
    NETH_POT("neth_pot", "Neth Pot"),
    SMP("smp", "SMP"),
    SWORD("sword", "Sword"),
    AXE("axe", "Axe"),
    MACE("mace", "Mace"),
    CART("cart", "Cart"),
    SPEAR_MACE("spearmace", "Spear Mace"),
    DIA_SMP("diasmp", "Dia SMP");

    public final String id;
    public final String display;

    GameMode(String id, String display) {
        this.id = id;
        this.display = display;
    }

    /** Private-use glyph that the cctiers:gm font maps to this mode's icon. */
    public char glyph() {
        return (char) (0xE000 + ordinal());
    }

    public static GameMode fromId(String id) {
        if (id == null) return null;
        for (GameMode m : values()) {
            if (m.id.equalsIgnoreCase(id)) return m;
        }
        return null;
    }

    /** Maps the API's keys to a mode ("nethop" -> Neth Pot, "diasmp" -> Dia SMP ...). */
    public static GameMode fromKey(String raw) {
        if (raw == null) return null;
        String k = raw.toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
        return switch (k) {
            case "vanilla", "ogvanilla", "diamondvanilla" -> VANILLA;
            case "crystal", "crystalpvp", "cpvp" -> CRYSTAL;
            case "uhc", "ironuhc" -> UHC;
            case "pot", "potion", "diapot", "diamondpot" -> POT;
            case "nethpot", "nethop", "nethpotion", "netheritepot" -> NETH_POT;
            case "smp", "netheritesmp" -> SMP;
            case "sword", "swordpvp" -> SWORD;
            case "axe", "axepvp" -> AXE;
            case "mace", "macepvp" -> MACE;
            case "cart", "minecart" -> CART;
            case "spearmace", "spear" -> SPEAR_MACE;
            case "diasmp", "diamondsmp" -> DIA_SMP;
            default -> null;
        };
    }
}
