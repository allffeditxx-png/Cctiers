package com.cctiers.data;

import java.util.Locale;

public enum GameMode {
    CRYSTAL("crystal", "Crystal"),
    SWORD("sword", "Sword"),
    AXE("axe", "Axe"),
    POT("pot", "Pot"),
    NETH_POT("neth_pot", "Neth Pot"),
    SMP("smp", "SMP"),
    MACE("mace", "Mace"),
    UHC("uhc", "UHC"),
    VANILLA("vanilla", "Vanilla");

    public final String id;
    public final String display;

    GameMode(String id, String display) {
        this.id = id;
        this.display = display;
    }

    /** Private-use glyph that cctiers:gm font maps to this mode's icon. */
    public char glyph() {
        return (char) (0xE000 + ordinal());
    }

    public static GameMode fromId(String id) {
        if (id == null) return null;
        for (GameMode m : values()) {
            if (m.id.equalsIgnoreCase(id)) return m;
        }
        return null;
    }

    /** Lenient lookup so different API spellings still map ("Neth Pot", "nethop", "diamond_smp"...). */
    public static GameMode fromKey(String raw) {
        if (raw == null) return null;
        String k = raw.toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
        return switch (k) {
            case "crystal", "crystalpvp", "cpvp" -> CRYSTAL;
            case "sword", "swordpvp" -> SWORD;
            case "axe", "axepvp" -> AXE;
            case "pot", "potion", "diapot", "diamondpot", "potpvp" -> POT;
            case "nethpot", "nethop", "nethpotion", "netheritepot", "nethpotpvp" -> NETH_POT;
            case "smp", "diamondsmp", "netheritesmp" -> SMP;
            case "mace", "macepvp" -> MACE;
            case "uhc", "ironuhc" -> UHC;
            case "vanilla", "ogvanilla", "diamondvanilla" -> VANILLA;
            default -> null;
        };
    }
}
