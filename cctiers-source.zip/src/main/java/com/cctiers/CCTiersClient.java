package com.cctiers;

import com.cctiers.config.CCConfig;
import com.cctiers.data.TierApi;
import com.cctiers.ui.CCCommands;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.gui.screen.Screen;

import java.util.function.Supplier;

public class CCTiersClient implements ClientModInitializer {
    public static final String MOD_ID = "cctiers";

    private static Supplier<Screen> pendingScreen;
    private static int tick = 0;
    private static volatile boolean registering = false;
    private static volatile long nextRegisterAt = 0L;

    @Override
    public void onInitializeClient() {
        CCConfig.load();
        ClientCommandRegistrationCallback.EVENT.register(CCCommands::register);
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Screens opened from a command have to wait a tick, otherwise the closing chat screen replaces them.
            if (pendingScreen != null) {
                Supplier<Screen> s = pendingScreen;
                pendingScreen = null;
                client.setScreen(s.get());
            }
            if (client.player == null) return;
            CCConfig c = CCConfig.get();
            if (!c.enabled) return;

            // first use: register the local player on the API
            if (c.registerPlayer && !c.registered && !registering && System.currentTimeMillis() >= nextRegisterAt) {
                registerNow(client);
            }

            // keep tiers of everyone online loaded, so tags are ready before they are drawn
            if (++tick % 40 == 0) {
                ClientPlayNetworkHandler handler = client.getNetworkHandler();
                if (handler != null) {
                    int n = 0;
                    for (PlayerListEntry e : handler.getPlayerList()) {
                        TierApi.get(e.getProfile().name());
                        if (++n >= 100) break;
                    }
                }
            }
        });
    }

    /** POST /players for the local player. Used on first launch and by /cctiers register. */
    public static void registerNow(MinecraftClient client) {
        if (client.player == null || registering) return;
        registering = true;
        String name = client.player.getName().getString();
        String uuid = client.player.getUuid().toString();
        TierApi.register(name, uuid, ok -> {
            if (ok) {
                CCConfig.get().registered = true;
                CCConfig.save();
            } else {
                nextRegisterAt = System.currentTimeMillis() + 60_000L;
            }
            registering = false;
        });
    }

    public static void openNextTick(Supplier<Screen> screen) {
        pendingScreen = screen;
    }
}
