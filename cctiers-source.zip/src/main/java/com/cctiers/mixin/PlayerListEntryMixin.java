package com.cctiers.mixin;

import com.cctiers.util.TierTags;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** The tab list draws names from PlayerListEntry#getDisplayName (null for normal players). */
@Mixin(PlayerListEntry.class)
public abstract class PlayerListEntryMixin {

    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void cctiers$addTag(CallbackInfoReturnable<Text> cir) {
        Text tagged = TierTags.tab((PlayerListEntry) (Object) this, cir.getReturnValue());
        if (tagged != null) cir.setReturnValue(tagged);
    }
}
